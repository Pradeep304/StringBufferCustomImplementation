import java.io.Serializable;
import java.util.Arrays;

/**
 * String buffer Custom Implementation
 * @author Pradeep.H
 *
 */
public final class StringBufferCustomImpl implements Serializable{
	/**
	 * A cache of the last value returned by toString. 
	 * It will not be serialized when this class gets serialized
	 */
	private transient char[] toStringTransient;
	/**
	 * SVU
	 */
	private static final long serialVersionUID = -3449958265502931716L;
	/**
	 * The value is used for character storage.
	 */
	char[] value;
	/**
	 * The count is the number of characters used.
	 */
	int count;

	/**
	 * Constructors with initial capacity of 10 (can change if needed)
	 */
	public StringBufferCustomImpl(){
		this(10);
	}

	public StringBufferCustomImpl(int capacity){
		value = new char[capacity];
	}
	
    public StringBufferCustomImpl(String str) {
        this(str.length() + 10);
        append(str);
    }

    /** 
     * length of the char array, synchronized for multithread environment
     * @return
     */
	public synchronized int length() {
		return count;
	}
	
	/**
	 * Capacity of the char array, synchronized, synchronized for multithread environment
	 * @return
	 */
	public synchronized int capacity() {
		return value.length;
	}
	
	/**
	 * Append method which appends the given string, synchronized for multithread environment
	 * @param str
	 * @return
	 */
	public synchronized StringBufferCustomImpl append(String str) {
		toStringTransient = null;
		if (str == null)
			return appendNull();
		int len = str.length();
		ensureCapacity(count + len);
		str.getChars(0, len, value, count);
		count += len;
		return this;
	}
	
	/**
	 * Append null if the string is null
	 * @return
	 */
	private StringBufferCustomImpl appendNull() {
		int c = count;
		ensureCapacity(c + 4);
		final char[] value = this.value;
		value[c++] = 'n';
		value[c++] = 'u';
		value[c++] = 'l';
		value[c++] = 'l';
		count = c;
		return this;
	}
	
	/**
	 * Ensure the capacity, if overflow expand it
	 * @param minimumCapacity
	 */
	private void ensureCapacity(int minimumCapacity) {
		// Check for overflow
		if (minimumCapacity - value.length > 0)
			expandCapacity(minimumCapacity);
	}
	
	/**
	 * Expand the capacity
	 * @param minimumCapacity
	 */
	private void expandCapacity(int minimumCapacity) {
		int newCapacity = value.length * 2;
		if (newCapacity - minimumCapacity < 0)
			newCapacity = minimumCapacity;
		if (newCapacity < 0) {
			if (minimumCapacity < 0) // overflow then throw OutOfMemoryError
				throw new OutOfMemoryError();
			newCapacity = Integer.MAX_VALUE;
		}
		value = Arrays.copyOf(value, newCapacity);
	}
	
	/**
	 * toString method which gives the string representation of given char array
	 */
	public synchronized String toString() {
        if (toStringTransient == null) {
        	toStringTransient = Arrays.copyOfRange(value, 0, count);
        }
        return new String(toStringTransient);
    }
}
