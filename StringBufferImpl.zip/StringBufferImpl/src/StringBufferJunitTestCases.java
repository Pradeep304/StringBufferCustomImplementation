import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Test cases for StringBuffer Custom Implementation
 * @author Pradeep.H
 *
 */
public class StringBufferJunitTestCases {
	
	/**
	 * Test case for char array contents
	 */
	@Test
	public void testCharArray() {
		StringBufferCustomImpl string = new StringBufferCustomImpl("Betsol");
		assertArrayEquals("Betsol".toCharArray(), string.toString().toCharArray());
		assertNotEquals("Betsol", string);
	}
	
	/**
	 * Test case for char array length
	 */
	@Test
	public void testLength() {
		StringBufferCustomImpl string = new StringBufferCustomImpl("Betsol");
		string.append(" Software");
		assertTrue("Betsol Software".length() == string.length());
    	assertTrue("Betsol Software".length() == string.count);
	}
	
	/**
	 * Test case for toString method
	 */
	@Test
	public void testtoString() {
		StringBufferCustomImpl string = new StringBufferCustomImpl("Betsol");
		string.append(" Software");
    	assertFalse("Betsol Software".toString() == string.toString());
	}
	
	/**
	 * Test case for char array capacity
	 */
	@Test
	public void testCapacity() {
		StringBufferCustomImpl string = new StringBufferCustomImpl("Betsol");
		string.append(" Software");
    	assertFalse(10 == string.capacity());
	}
}
